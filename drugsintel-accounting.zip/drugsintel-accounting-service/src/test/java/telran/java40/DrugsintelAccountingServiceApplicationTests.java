package telran.java40;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrugsintelAccountingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
