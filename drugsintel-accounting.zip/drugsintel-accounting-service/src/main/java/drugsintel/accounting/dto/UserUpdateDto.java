package drugsintel.accounting.dto;

import lombok.Getter;

@Getter
public class UserUpdateDto {
	String username;
	String email;
}
