package drugsintel.accounting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrugsintelAccountingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrugsintelAccountingServiceApplication.class, args);
	}

}
